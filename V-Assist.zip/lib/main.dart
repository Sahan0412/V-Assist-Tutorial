import 'dart:html';

import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/widgets.dart';
import 'package:open_file/open_file.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:qrscan/qrscan.dart' as scanner;

void main() => runApp(VAssistApp());
List<String> locations = ['Kacheguda', 'TilakNager', 'Chikkadpally'];
List<String> vehicleTypes = ['2 Wheeler', '4 Wheeler', 'Bus', 'Goods Carrier'];
List<String> strings = ['Registartion Number', 'Chasis Number', 'TR no.'];
void _pickFile() async {
  final result = await FilePicker.platform.pickFiles(allowMultiple: false);

  // if no file is picked
  if (result == null) return;
  print(result.files.first.name);
  print(result.files.first.size);
  print(result.files.first.path);
}

class VAssistApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'V-Assist',
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('V-Assist'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Choose Login Type"),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => UserLoginPage()),
                );
              },
              child: Text('User Login'),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PoliceLoginPage()),
                );
              },
              child: Text('Police Login'),
            ),
          ],
        ),
      ),
    );
  }
}

class UserLoginPage extends StatefulWidget {
  @override
  _UserLoginPageState createState() => _UserLoginPageState();
}

class _UserLoginPageState extends State<UserLoginPage> {
  String userId = '';
  String vehicleNumber = '';
  String password = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('User Login'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 16),
            Text('User ID'),
            TextField(
              onChanged: (value) {
                setState(() {
                  userId = value;
                });
              },
            ),
            SizedBox(height: 16),
            Text('Vehicle Number'),
            TextField(
              onChanged: (value) {
                setState(() {
                  vehicleNumber = value;
                });
              },
            ),
            SizedBox(height: 16),
            Text('Password'),
            TextField(
              obscureText: true,
              onChanged: (value) {
                setState(() {
                  password = value;
                });
              },
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => LoggedInUser1()),
                );
              },
              child: Text('Login'),
            ),
            SizedBox(height: 16),
            TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => RegisterPage()),
                );
              },
              child: Text('Register'),
            ),
          ],
        ),
      ),
    );
  }
}

class PoliceLoginPage extends StatefulWidget {
  @override
  _PoliceLoginPageState createState() => _PoliceLoginPageState();
}

class _PoliceLoginPageState extends State<PoliceLoginPage> {
  String badgeNumber = '';
  String password = '';
  String vno = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Police Login'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 16),
            Text('Badge Number'),
            TextField(
              onChanged: (value) {
                setState(() {
                  badgeNumber = value;
                });
              },
            ),
            SizedBox(height: 16),
            Text('Password'),
            TextField(
              obscureText: true,
              onChanged: (value) {
                setState(() {
                  password = value;
                });
              },
            ),
            SizedBox(height: 16),
            Text('User Vehicle Number'),
            TextField(
              //obscureText: true,
              onChanged: (value) {
                setState(() {
                  vno = value;
                });
              },
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => LoggedInPolice1()),
                );
              },
              child: Text('Login'),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ChallanPage()),
                );
              },
              child: Text('Generate Challan'),
            ),
          ],
        ),
      ),
    );
  }
}

class RegisterPage extends StatefulWidget {
  @override
  _RegisterPageState createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  String userEmail = '';
  String vehicleNumber = '';
  String password = '';
  String confirmPassword = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('User Login'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 16),
            Text('User Email'),
            TextField(
              onChanged: (value) {
                setState(() {
                  userEmail = value;
                });
              },
            ),
            SizedBox(height: 16),
            Text('Vehicle Number'),
            TextField(
              onChanged: (value) {
                setState(() {
                  vehicleNumber = value;
                });
              },
            ),
            SizedBox(height: 16),
            Text('Password'),
            TextField(
              obscureText: true,
              onChanged: (value) {
                setState(() {
                  password = value;
                });
              },
            ),
            SizedBox(height: 16),
            Text('Confirm Password'),
            TextField(
              obscureText: true,
              onChanged: (value) {
                setState(() {
                  confirmPassword = value;
                });
              },
            ),
            SizedBox(height: 16),
            TextButton(
              onPressed: () {},
              child: Text('Register'),
            ),
          ],
        ),
      ),
    );
  }
}

class ChallanPage extends StatefulWidget {
  @override
  _ChallanPageState createState() => _ChallanPageState();
}

class _ChallanPageState extends State<ChallanPage> {
  String selectedLocation = locations.first;
  String selectedVehicleType = vehicleTypes.first;
  String fullName = '';
  String vAssistId = '';
  String vehicleNumber = '';
  String reason = '';
  int challanAmount = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Challan Generation'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 8),
              Text('Location'),
              DropdownButton<String>(
                value: selectedLocation,
                onChanged: (String? newValue) {
                  setState(() {
                    selectedLocation = newValue!;
                  });
                },
                items: locations.map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                // ensure that there is at least one item with the dropdown value
                selectedItemBuilder: (BuildContext context) {
                  return locations.map<Widget>((String value) {
                    return Text(selectedLocation);
                  }).toList();
                },
              ),
              SizedBox(height: 8),
              Text('Vehicle Type'),
              DropdownButton<String>(
                value: selectedVehicleType,
                onChanged: (String? newValue) {
                  setState(() {
                    selectedVehicleType = newValue!;
                  });
                },
                items:
                    vehicleTypes.map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                // ensure that there is at least one item with the dropdown value
                selectedItemBuilder: (BuildContext context) {
                  return vehicleTypes.map<Widget>((String value) {
                    return Text(selectedVehicleType);
                  }).toList();
                },
              ),
              SizedBox(height: 8),
              Text('Full Name'),
              TextField(
                onChanged: (value) {
                  setState(() {
                    fullName = value;
                  });
                },
              ),
              SizedBox(height: 8),
              Text('V-Assist ID'),
              TextField(
                onChanged: (value) {
                  setState(() {
                    vAssistId = value;
                  });
                },
              ),
              SizedBox(height: 8),
              SizedBox(height: 8),
              Text('Reason'),
              TextField(
                onChanged: (value) {
                  setState(() {
                    reason = value;
                  });
                },
              ),
              SizedBox(height: 8),
              Text('Challan Amount'),
              TextField(
                onChanged: (value) {
                  setState(() {
                    challanAmount = int.parse(value);
                  });
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class LoggedInUser1 extends StatefulWidget {
  @override
  _LoggedInUser1 createState() => _LoggedInUser1();
}

class _LoggedInUser1 extends State<LoggedInUser1> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('User Account'),
        backgroundColor: Colors.redAccent,
        actions: [
          PopupMenuButton(
              // add icon, by default "3 dot" icon
              // icon: Icon(Icons.book)
              itemBuilder: (context) {
            return [
              PopupMenuItem<int>(
                value: 0,
                child: Text("My QR"),
              ),
              PopupMenuItem<int>(
                value: 1,
                child: Text("Logout"),
              ),
            ];
          }, onSelected: (value) {
            if (value == 0) {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => UserQR()),
              );
            } else if (value == 1) {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => UserLoginPage()),
              );
            }
          }),
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
                "Name: K Sahan Vihar Reddy\nVehicle Number: TS11EK6468\nAge:19\nVehicleType:4 Wheeler\nModel:Nissan Magnite\n"),
            SizedBox(height: 16),
            TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => StaticUpload()),
                );
              },
              child: Text('Click For Static Update'),
            ),
            SizedBox(height: 16),
            TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => UserFines()),
                );
              },
              child: Text('Fines/Challans'),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AddDocuments()),
                );
              },
              child: Text('Vehicle Documents'),
            ),
          ],
        ),
      ),
    );
  }
}

class AddDocuments extends StatefulWidget {
  @override
  _AddDocuments createState() => _AddDocuments();
}

class _AddDocuments extends State<AddDocuments> {
  String lno = '';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Vehcile Documents'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Vehicle Registration Certificate"),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                _pickFile();
              },
              child: Text('add document'),
            ),
            Text("\nPollution Check"),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                _pickFile();
              },
              child: Text('add document'),
            ),
            Text("\nVehicle Insurance"),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                _pickFile();
              },
              child: Text('add document'),
            ),
            Text("\nAdd Driving License?"),
            TextField(
              onChanged: (value) {
                setState(() {
                  lno = value;
                });
              },
            ),
            //Text("\nPollution Check"),
            SizedBox(height: 16),
            TextButton(
              onPressed: () {},
              child: Text('add'),
            ),
            Text("\nUpload Soft Copy?"),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                _pickFile();
              },
              child: Text('add document'),
            ),
          ],
        ),
      ),
    );
  }
}

class StaticUpload extends StatefulWidget {
  @override
  _StaticUpload createState() => _StaticUpload();
}

class _StaticUpload extends State<StaticUpload> {
  TextEditingController dateinput = TextEditingController();
  String option = strings.first;
  String otype = '';
  String ino = '';
  String pno = '';
  String polno = '';
  void initState() {
    dateinput.text = ""; //set the initial value of text field
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('User Portal'),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("Enter the required updated details."),
              Text("\nRegistration Certificate Upload"),
              DropdownButton<String>(
                value: option,
                onChanged: (String? newValue) {
                  setState(() {
                    option = newValue!;
                  });
                },
                items: strings.map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                // ensure that there is at least one item with the dropdown value
                selectedItemBuilder: (BuildContext context) {
                  return locations.map<Widget>((String value) {
                    return Text(option);
                  }).toList();
                },
              ),
              Text("\nEnter Option Type Value:"),
              TextField(
                onChanged: (value) {
                  setState(() {
                    ino = value;
                  });
                },
              ),
              //Text("\nPollution Check"),
              SizedBox(height: 8),
              TextButton(
                onPressed: () {},
                child: Text('update linked RC'),
              ),
              Text("\nInsurance Update"),
              Text("Policy Number:"),
              TextField(
                onChanged: (value) {
                  setState(() {
                    pno = value;
                  });
                },
              ),
              TextField(
                controller: dateinput,
                decoration: InputDecoration(
                    icon: Icon(Icons.calendar_today), labelText: "Valid Till:"),
                readOnly: true,
                onTap: () async {
                  DateTime? pickedDate = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(
                          2023), //DateTime.now() - not to allow to choose before today.
                      lastDate: DateTime(2028));

                  if (pickedDate != null) {
                    print(
                        pickedDate); //pickedDate output format => 2021-03-10 00:00:00.000
                    String formattedDate =
                        DateFormat('yyyy-MM-dd').format(pickedDate);
                    print(
                        formattedDate); //formatted date output using intl package =>  2021-03-16
                    //you can implement different kind of Date Format here according to your requirement

                    setState(() {
                      dateinput.text =
                          formattedDate; //set output date to TextField value.
                    });
                  } else {
                    print("Date is not selected");
                  }
                },
              ),
              SizedBox(height: 8),
              TextButton(
                onPressed: () {},
                child: Text('update insurance details'),
              ),
              Text("\nPollution Check Details"),
              Text("Renewal Number:"),
              TextField(
                onChanged: (value) {
                  setState(() {
                    polno = value;
                  });
                },
              ),
              TextField(
                controller: dateinput,
                decoration: InputDecoration(
                    icon: Icon(Icons.calendar_today), labelText: "Valid Till:"),
                readOnly: true,
                onTap: () async {
                  DateTime? pickedDate = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(
                          2023), //DateTime.now() - not to allow to choose before today.
                      lastDate: DateTime(2028));

                  if (pickedDate != null) {
                    print(
                        pickedDate); //pickedDate output format => 2021-03-10 00:00:00.000
                    String formattedDate =
                        DateFormat('yyyy-MM-dd').format(pickedDate);
                    print(
                        formattedDate); //formatted date output using intl package =>  2021-03-16
                    //you can implement different kind of Date Format here according to your requirement

                    setState(() {
                      dateinput.text =
                          formattedDate; //set output date to TextField value.
                    });
                  } else {
                    print("Date is not selected");
                  }
                },
              ),
              //SizedBox(height: 8),
              TextButton(
                onPressed: () {},
                child: Text('update pollution details'),
              )
            ],
          ),
        ),
      ),
    );
  }
}

class UserFines extends StatefulWidget {
  @override
  _UserFines createState() => _UserFines();
}

class _UserFines extends State<UserFines> {
  LaunchURL(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }

  //String lno = '';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Vehcile Documents'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
                "Reason: Expired Document\nDocument Type: Vehicle Insurance\nAmount: Rs2500/-\nPS: Kacheguda\nOfficer: Vijay Simha Reddy\nDated:30:12:2022"),
            ElevatedButton(
              onPressed: () {
                const url = 'https://echallan.tspolice.gov.in/publicview/';
                LaunchURL(url);
              },
              child: Text('Pay All'),
            ),
            SizedBox(height: 8),
            ElevatedButton(
              onPressed: () {
                const url = 'https://www.policybazaar.com/motor-insurance/';
                LaunchURL(url);
              },
              child: Text('Renew Insurance'),
            ),
          ],
        ),
      ),
    );
  }
}

class LoggedInPolice1 extends StatefulWidget {
  @override
  _LoggedInPolice1 createState() => _LoggedInPolice1();
}

class _LoggedInPolice1 extends State<LoggedInPolice1> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text('User Account'),
          backgroundColor: Colors.redAccent,
          actions: [
            PopupMenuButton(
                // add icon, by default "3 dot" icon
                // icon: Icon(Icons.book)
                itemBuilder: (context) {
              return [
                PopupMenuItem<int>(
                  value: 0,
                  child: Text("My Profile"),
                ),
                PopupMenuItem<int>(
                  value: 1,
                  child: Text("Logout"),
                ),
                PopupMenuItem<int>(
                  value: 2,
                  child: Text("Scan Qr"),
                ),
              ];
            }, onSelected: (value) {
              if (value == 0) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PoliceProfile()),
                );
              } else if (value == 1) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PoliceLoginPage()),
                );
              } else if (value == 2) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => CamScanner()),
                );
              }
            }),
          ]),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("\nPolice Name: Vijay Simha Reddy\npId:27091996\n"),
            Text(
                "\n\nName: K Sahan Vihar Reddy\nVehicle Number: TS11EK6468\nAge:19\nVehicleType:4 Wheeler\nModel:Nissan Magnite\n"),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PoliceCheckDoc()),
                );
              },
              child: Text('Verify Documents'),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {},
              child: Text('Add Fine(s)'),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PolicePendingFines()),
                );
              },
              child: Text('Pending Challan(s)'),
            ),
          ],
        ),
      ),
    );
  }
}

class PoliceCheckDoc extends StatefulWidget {
  @override
  _PoliceCheckDoc createState() => _PoliceCheckDoc();
}

class _PoliceCheckDoc extends State<PoliceCheckDoc> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Police Account'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Registration Cetificate\nReg No:8976056 192083"),
            Text("Status: Valid", style: TextStyle(color: Color(0xff008b05))),
            TextButton(
              onPressed: () {},
              child: Text('Verify Document'),
            ),
            SizedBox(height: 16),
            Text("Insurance\nPolicy No:73678965"),
            Text(
              "Status:EXPIRED!",
              style: TextStyle(color: Colors.red),
            ),
            TextButton(
              onPressed: () {},
              child: Text('Verify Document'),
            ),
            SizedBox(height: 16),
            Text("Pollution Check\nReg No:09870897"),
            Text("Status: Valid", style: TextStyle(color: Color(0xff008b05))),
            TextButton(
              onPressed: () {},
              child: Text('Verify Document'),
            ),
            Text("\n\nAdded Driving License\n"),
            TextButton(
              onPressed: () {},
              child: Text('License1'),
            ),
            //Text("\n"),
            TextButton(
              onPressed: () {},
              child: Text('License2'),
            ),
          ],
        ),
      ),
    );
  }
}

class PolicePendingFines extends StatefulWidget {
  @override
  _PolicePendingFines createState() => _PolicePendingFines();
}

class _PolicePendingFines extends State<PolicePendingFines> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Pending Fines'),
        ),
        body: Center(
            child: Column(children: <Widget>[
          Container(
            margin: EdgeInsets.all(20),
            child: Table(
              defaultColumnWidth: FixedColumnWidth(120.0),
              border: TableBorder.all(
                  color: Colors.black, style: BorderStyle.solid, width: 2),
              children: [
                TableRow(children: [
                  Column(children: [
                    Text('S.no.', style: TextStyle(fontSize: 20.0))
                  ]),
                  Column(children: [
                    Text('Reason', style: TextStyle(fontSize: 20.0))
                  ]),
                  Column(children: [
                    Text('Location', style: TextStyle(fontSize: 20.0))
                  ]),
                  Column(children: [
                    Text('Date', style: TextStyle(fontSize: 20.0))
                  ]),
                  Column(children: [
                    Text('Amount(in Rs.)', style: TextStyle(fontSize: 20.0))
                  ]),
                ]),
                TableRow(children: [
                  Column(children: [Text('1')]),
                  Column(children: [Text('Signal Jump')]),
                  Column(children: [Text('Tilaknagar X Roads')]),
                  Column(children: [Text('04-May-2022')]),
                  Column(children: [Text('1000/-')]),
                ]),
                TableRow(children: [
                  Column(children: [Text('2')]),
                  Column(children: [Text('Signal Jump')]),
                  Column(children: [Text('Kachedguda Signal')]),
                  Column(children: [Text('19-Aug-2022')]),
                  Column(children: [Text('1000/-')]),
                ]),
                TableRow(children: [
                  Column(children: [Text('3')]),
                  Column(children: [Text('Wrong Parking')]),
                  Column(children: [Text('Liberty RTO Office Lane')]),
                  Column(children: [Text('17-Apr-2023')]),
                  Column(children: [Text('1000/-')]),
                ]),
                TableRow(children: [
                  Column(children: [Text(' ')]),
                  Column(children: [Text(' ')]),
                  Column(children: [Text(' ')]),
                  Column(children: [Text('Total:')]),
                  Column(children: [Text('3000/-')]),
                ]),
              ],
            ),
          ),
          ElevatedButton(
            onPressed: () {
              showDialog(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: const Text("Remainder"),
                  content: const Text("Reminder sent to XXXXXX0886"),
                  actions: <Widget>[
                    TextButton(
                      onPressed: () {
                        Navigator.of(ctx).pop();
                      },
                      child: Container(
                        color: Color(0xffb5adad),
                        padding: const EdgeInsets.all(14),
                        child: const Text("OKAY"),
                      ),
                    ),
                  ],
                ),
              );
            },
            child: const Text("Send Remainder"),
          ),
        ])));
  }
}

class UserQR extends StatefulWidget {
  @override
  _UserQR createState() => _UserQR();
}

class _UserQR extends State<UserQR> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('User Account'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.network(
                'https://upload.wikimedia.org/wikipedia/commons/d/d0/QR_code_for_mobile_English_Wikipedia.svg'),
            ElevatedButton(
              onPressed: () {
                //onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PoliceCheckDoc()),
                );
              },
              child: Text('Scan UserQR'),
            ),
          ],
        ),
      ),
    );
  }
}

class PoliceProfile extends StatefulWidget {
  @override
  _PoliceProfile createState() => _PoliceProfile();
}

class _PoliceProfile extends State<PoliceProfile> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('User Account'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset('assets/ProfilePic.jpeg'),
            Text(
                "Name: Vijay Simha Reddy\n PS: Nallakunta Police Station\n Badge Number:09887\npId:27091996"),
          ],
        ),
      ),
    );
  }
}

class CamScanner extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _CamScanner(); //create state
  }
}

class _CamScanner extends State<CamScanner> {
  String scanresult = 'none';

  @override
  void initState() {
    scanresult = "none"; //innical value of scan result is "none"
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text("QR or Bar code Scanner"),
          backgroundColor: Colors.redAccent),
      body: Container(
          alignment: Alignment.topCenter, //inner widget alignment to center
          padding: EdgeInsets.all(20),
          child: Column(
            children: [
              Container(child: Text("Scan Result: " + scanresult)),
              Container(
                  margin: EdgeInsets.only(top: 30),
                  child: TextButton(
                      //button to start scanning
                      //color: Colors.redAccent,
                      //colorBrightness: Brightness.dark,
                      onPressed: () async {
                        scanresult = await scanner.scan() ?? "none";

                        setState(() {
                          //refresh UI to show the result on app
                        });
                      },
                      child: Text("Scan QR or Bar Code")))
            ],
          )),
    );
  }
}
